package metodos;

import java.sql.ResultSet;

import java.sql.SQLException;

import Pantallas.Cobro2;
import Pantallas.mesas_cobro;
import Pantallas.MesaResumen;
import Pantallas.Restaurante;

import javax.swing.*;

public class metodos{

	public void mesas(int a) 
	{
		ConexionBasedeDatos.ConexionMySQL x = new ConexionBasedeDatos.ConexionMySQL("root", "", "Registro");

		try {
			x.conectar();
			String sentencia = "SELECT * FROM seleccion_producto WHERE Identificador= '"+a+"'";
			ResultSet z = x.ejecutarSelect(sentencia);
			Restaurante.total = 0;
			Restaurante.mesa = 0;
			String Producto = "";
			Restaurante.mensaje = "           Producto      " + "              Precio";
			while (z.next()) {

				Restaurante.mensaje += "\n          " + z.getString("Producto") + "                      "
						+ z.getInt("Precio");
				Restaurante.total += z.getInt("Precio");
				Restaurante.mesa = z.getInt("Identificador");
				

			}
			MesaResumen y = new MesaResumen();
			y.setVisible(true);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	public void resumencobro(int v) 
	{
		ConexionBasedeDatos.ConexionMySQL x = new ConexionBasedeDatos.ConexionMySQL("root", "", "Registro");
		

		try {
			x.conectar();
			String sentencia = "SELECT * FROM seleccion_producto WHERE Identificador= '"+v+"'";
			ResultSet z = x.ejecutarSelect(sentencia);
			
			if(!z.next()) 
			{
				JOptionPane.showMessageDialog(null, "Mesa vacia o cobrada");
			}
			else {
			mesas_cobro.total = 0;
			mesas_cobro.mesa= z.getInt("Identificador");
			mesas_cobro.total=z.getInt("Precio");
			
			while (z.next()) {
				mesas_cobro.total += z.getInt("Precio");
			}
			Cobro2 b = new Cobro2();
			b.setVisible(true);
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}

			public void Sign_in(String usuario, String password, JFrame ventana) {
				ConexionBasedeDatos.ConexionMySQL x = new ConexionBasedeDatos.ConexionMySQL("root", "", "registro");

				if (usuario.equals("") || password.equals("")) {
                    try {
                        throw new SQLException();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }

				}
				else {
					try {
						x.conectar();

						String z = "SELECT * FROM users";
						ResultSet comparar = x.ejecutarSelect(z);
						boolean encontrado = false;
						while (comparar.next()) {
							String user = comparar.getString("Usuario");
							if (usuario.equals(user)) {
								encontrado = true;
								break;
							}
						}

						if (encontrado) {
							JOptionPane.showMessageDialog(null, "Este nombre de usuario ya existe.\nIntroduzca otro distinto.");
						} else {
							String y = "INSERT INTO users(Usuario, Contraseña) VALUES('" + usuario + "','" + password + "')";
							x.ejecutarInsertDeleteUpdate(y);
							JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente.");
							ventana.dispose(); // ✅ cerrar la ventana actual
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		}

	


