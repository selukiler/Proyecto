package JUnit;
import ConexionBasedeDatos.ConexionMySQL;
import Pantallas.Registro;
import Pantallas.RegistroProductos;
import Pantallas.mesas_cobro;
import metodos.metodos;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
public class Tests {

    @Test
    void registroProductos_camposVacios_noDebeRegistrar() {
        RegistroProductos ventana = new RegistroProductos();
        ventana.setVisible(false);
        ventana.txt_producto.setText("");
        ventana.txt_precio.setText("");
        ventana.txt_descripcion.setText("");
        assertTrue(ventana.txt_producto.getText().isEmpty());
        assertTrue(ventana.txt_precio.getText().isEmpty());
        assertTrue(ventana.txt_descripcion.getText().isEmpty());
    }
    metodos metodo= new metodos();

    @Test
    void iniciosesion_usuarioVacio_noInserta() throws SQLException {
        ConexionMySQL conexion = new ConexionMySQL("root", "", "Registro");
        conexion.conectar();
        String usuario = "";
        String password = "1234";
        Registro ventana = new Registro();
        ventana.setVisible(false);

        RuntimeException exception = assertThrows(RuntimeException.class, () ->  metodo.Sign_in(usuario,password,ventana));
        assertNotNull(exception);
    }


    @Test
    public void CamposVacios() {
        RegistroProductos rp = new RegistroProductos();

        // Campos vacíos
        rp.txt_producto.setText("");
        rp.txt_precio.setText("");
        rp.txt_descripcion.setText("");

        boolean resultado = rp.txt_producto.getText().isEmpty() ||
                rp.txt_precio.getText().isEmpty() ||
                rp.txt_descripcion.getText().isEmpty();

        assertTrue("Debe fallar si hay campos vacíos", resultado);
    }

    @Test
    public void ResumenCobroMesaVacia() {
        assertDoesNotThrow(() -> {
            metodo.resumencobro(-999); // Mesa inválida
        }, "Debe manejar mesa vacía correctamente sin excepciones");
    }

    @Test
    public void testMesasConIdentificadorInvalido() {
        assertDoesNotThrow(() -> {
            metodo.mesas(-999); // Un ID inválido que no devuelve nada
        }, "Debe manejar un ID inválido sin lanzar excepciones");
    }

    @Test
    public void testCamposCompletos() {
        RegistroProductos rp = new RegistroProductos();

        rp.txt_producto.setText("Tarta");
        rp.txt_precio.setText("15.0");
        rp.txt_descripcion.setText("Postre dulce");

        assertTrue("Debe aceptar si todos los campos están completos", !rp.txt_producto.getText().isEmpty() &&
                        !rp.txt_precio.getText().isEmpty() &&
                        !rp.txt_descripcion.getText().isEmpty());
    }


    @Test
    public void testCampoProductoVacio() {
        RegistroProductos rp = new RegistroProductos();

        rp.txt_producto.setText("");
        rp.txt_precio.setText("10.0");
        rp.txt_descripcion.setText("Prueba");

        assertFalse(!rp.txt_producto.getText().isEmpty() &&
                        !rp.txt_precio.getText().isEmpty() &&
                        !rp.txt_descripcion.getText().isEmpty(), "No debe aceptar si falta el nombre del producto");
    }
}

